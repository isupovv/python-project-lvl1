#!/usr/bin/env python
from brain_games.even import game


def main():
    print('Welcome to the Brain Games!')
    game()
